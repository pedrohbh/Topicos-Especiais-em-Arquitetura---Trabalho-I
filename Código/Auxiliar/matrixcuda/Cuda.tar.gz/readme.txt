parametros:

-tam = define o tamanho da matriz
-qtd = qtd de iteracoes que sera rodado

Exemplo:
  matrizCuda -tam=1024 -qtd=100

Executa 100 vezes a multiplicacao de uma matrix de tamanho 1024 x 1024	
